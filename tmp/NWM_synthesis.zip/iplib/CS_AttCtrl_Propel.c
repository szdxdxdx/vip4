#include "CS_AttCtrl_Propel.h"

void PhasePlaneJetControl(void *p , float64 ThetaC_in, float64 dThetaC_in, unint32 axis, float64 as_PP, float64 aL_PP, unint32 mode);
void CS_Chose_Switching_Line(void *p, unint32 mode);
void CS_AttCtrl_JetPulseCalc(void *p);
unint32 CS_ThrParamCfgX(unint32 m_WorkMode, float64 *ModeObjectTimer_Mode ,float64 csModePara_dt_PanelUnfold_Start ,
                        unint32 csSGAttAcqData_F_EarthAcq, unint32 csSGAttAcqData_F_YawCapt,
                        unint32 csIomScanPara_FP_GK_JetBack, unint32 csIomScanData_SMODE,
                        unint32 *csCtrlerOtherPara_FP_RWorCMGC, unint32 csWacqData_m_SubMode,
                        unint32 csJPCData_F_UldT);
void CS_AttCtrl_JetCrossSub(unint32 i, unint32 j, float64* csJPCData_mPhase_T, unint32* csJPCData_F_Jet, unint32* csJPCData_FJ);
void CS_AttCtrl_JetCrossCtrl(void *p);
void CS_FindMinMaxPos(unint32 *MinPos, unint32 *MaxPos, const float64 *a, const unint32 length);
void CS_AttCtrl_Jet12Dis(void *p);

void CS_AttCtrl_PropelFun(void *p)
{
    CS_AttCtrl_Propel *pIp = (CS_AttCtrl_Propel*)p;
    unint32 i;

    /* apn ��ֵ������������������� */
    for(i=0; i<3; i++)
    {
    	pIp->csJPCData_apn[i][0] = pIp->csJPCPara_as[pIp->csModeData_F_PanelUnfold][pIp->csJPCPara_FU&0x3][2*i+ 0] * DEG2RAD;
    	pIp->csJPCData_apn[i][1] = pIp->csJPCPara_as[pIp->csModeData_F_PanelUnfold][pIp->csJPCPara_FU&0x3][2*i+ 1] * DEG2RAD;
    }

    /* ����5.6.3.1.1����̬���������������㣩 */
    CS_AttCtrl_JetPulseCalc(pIp);

    /* ����5.6.3.1.2(�˿��������������) */
    CS_AttCtrl_JetCrossCtrl(pIp);

    /* ͣ�� �� ������������ */
    if ((pIp->csModeData_F_StopCtrl == 1) || (pIp->csJPCPara_FU == 0))
    {
        pIp->csJPCData_mPhase_T[0] = 0.0;
        pIp->csJPCData_mPhase_T[1] = 0.0;
        pIp->csJPCData_mPhase_T[2] = 0.0;
    }
    else
    {
        CS_AttCtrl_Jet12Dis(pIp);

        /* �������ܵ�������� */
        for (i=0; i<12; i++)
        {
            pIp->csJPCData_t[i] = pIp->csJPCData_t_AC[i];

        }
    }

    return;

}

unint32 CS_ThrParamCfgX(unint32 m_WorkMode, float64 *ModeObjectTimer_Mode ,float64 csModePara_dt_PanelUnfold_Start ,
                        unint32 csSGAttAcqData_F_EarthAcq, unint32 csSGAttAcqData_F_YawCapt,
                        unint32 csIomScanPara_FP_GK_JetBack, unint32 csIomScanData_SMODE,
                        unint32 *csCtrlerOtherPara_FP_RWorCMGC, unint32 csWacqData_m_SubMode,
                        unint32 csJPCData_F_UldT) {
    unint32 mode;

    /* ������ȷ��ѡ�ڼ��ֹ�������ƽ��ϵ�� */
    // WKMD_EIM 0x01u WKMD_AAM 0x08u
    // WKMD_OAM 0x06u WKMD_IOM 0x0Cu
    // WKMD_OCM 0x07u SUBMD_AAM_SPSM 0x02u
    if ((m_WorkMode == 0x01u) && (ModeObjectTimer_Mode[m_WorkMode] < csModePara_dt_PanelUnfold_Start))
    {
        mode = 0;              /* ����1���� */
    }
    else if((m_WorkMode == 0x06u) ||
            (m_WorkMode == 0x07u) ||
            ((m_WorkMode == 0x08u) && (csSGAttAcqData_F_EarthAcq == 1)) ||
            ((m_WorkMode == 0x08u) && (csSGAttAcqData_F_EarthAcq == 0) && (csSGAttAcqData_F_YawCapt == 1)) ||
            ((m_WorkMode == 0x0Cu) && (csIomScanPara_FP_GK_JetBack == 1) && (csIomScanData_SMODE == 10))  )

    {
        mode = 1;              /* ����2���� */
    }
    else
    {
        if ((m_WorkMode == 0x08u) &&
            (csCtrlerOtherPara_FP_RWorCMGC[0x08u] == 0) &&
            (csWacqData_m_SubMode == 0x02u))
        {
            /* �������� */
            mode = 2;          /* ����3���� */
        }
        else if (csJPCData_F_UldT == 1)
        {
            mode = 3;          /* ����4���� */
        }
        else
        {
            mode = 4;          /* ����5���� */
        }
    }

    return mode;
}

void CS_AttCtrl_JetPulseCalc(void *p)
{
    CS_AttCtrl_Propel *pIp = (CS_AttCtrl_Propel*)p;
    unint32 mode;


    /* ������� */
    // ipCS_Chose_Switching_Line.mode = mode;
    /* (1) ȷ��ѡ�ڼ��ֹ�������ƽ��ϵ�� */
    mode = CS_ThrParamCfgX(pIp->m_WorkMode, &pIp->ModeObjectTimer_Mode[0], pIp->csModePara_dt_PanelUnfold_Start,
                            pIp->csSGAttAcqData_F_EarthAcq, pIp->csSGAttAcqData_F_YawCapt,
                            pIp->csIomScanPara_FP_GK_JetBack, pIp->csIomScanData_SMODE,
                            &pIp->csCtrlerOtherPara_FP_RWorCMGC[0], pIp->csWacqData_m_SubMode,
                            pIp->csJPCData_F_UldT );

    /* (2) */
    CS_Chose_Switching_Line(pIp, mode);
    return;
}


void CS_Chose_Switching_Line(void *p, unint32 mode)
{
    CS_AttCtrl_Propel *pIp = (CS_AttCtrl_Propel*)p;
    float64 dA0[3];         /* ��̬������ʼ��̬���ٶ� */
    float64 ThetaC_in;
    float64 dThetaC_in;
    float64 as_PP;          /* С�������ٶ�,deg/s^2 */
    float64 aL_PP;          /* ���������ٶ�,deg/s^2 */
    unint32 axis;           /* ����ͨ�� */

    for (axis=0; axis<3; axis++)        /* axis = 0/1/2��Ӧ������������ƫ��ͨ�� */
    {
        ThetaC_in = pIp->csAttCoreData_A_c[axis] * RAD2DEG;

        if (Fabsx(ThetaC_in) > pIp->csJPCPara_theta_bp[mode][axis])
        {
            dA0[axis] = -pIp->csJPCPara_w_bp[mode][axis] * (float64)Sgn2(ThetaC_in);  /* ����  */
        }
        else
        {
            dA0[axis] = 0.0;
        }

        dThetaC_in = pIp->csAttCoreData_Rate_c[axis] * RAD2DEG - dA0[axis];

        if (pIp->csAttCoreData_A_c[axis] > 0)
        {
            /* as_neg */
            as_PP = pIp->csJPCPara_as[pIp->csModeData_F_PanelUnfold][pIp->csJPCPara_FU&0x3][2*axis+1];
        }
        else
        {
            /* as_pos */
            as_PP = pIp->csJPCPara_as[pIp->csModeData_F_PanelUnfold][pIp->csJPCPara_FU&0x3][2*axis+0];
        }

        as_PP = as_PP * pIp->csJPCPara_Mdf_as_PP;

        /* Ĭ��aL_PP����as_PP�����ͺ�������Ҫ���赥������ */
        aL_PP = as_PP;

        /* ���á�ֱ������ƽ��������̬�����㷨��Ʒ�淶�� */
        PhasePlaneJetControl(pIp, ThetaC_in, dThetaC_in, axis , as_PP , aL_PP, mode);
        
        if (pIp->csJPCData_mPhase_Region[axis] == 0x13)
        {
            pIp->csJPCData_mPhase_T[axis] = LimitDouble(pIp->csJPCData_mPhase_T[axis], pIp->csJPCPara_Mlf_t_R13);
        }

        if (pIp->csJPCData_mPhase_T[axis] > 0.0)
        {
            pIp->csJPCData_F_st[axis] = 1;
        }
        else
        {
            pIp->csJPCData_F_st[axis] = 0;
            pIp->csJPCData_mPhase_T[axis] = -pIp->csJPCData_mPhase_T[axis];
        }

        pIp->csJPCData_F_Jet[axis] = pIp->csJPCData_mPhase_FJB[axis];
    }

    return;
}

void PhasePlaneJetControl(void *p , float64 ThetaC_in, float64 dThetaC_in, unint32 axis, float64 as_PP, float64 aL_PP, unint32 mode)
{
    CS_AttCtrl_Propel *pIp = (CS_AttCtrl_Propel*)p;
    siint32 SgnA;
    float64 ThetaC;
    float64 dThetaC;
    float64 Switch1;
    float64 Switch2;
    float64 Switch3;
    float64 tmp_pst;
    float64 TN1;
    float64 TN2;
    float64 tmp_TN;

    SgnA = Sgn2(ThetaC_in);
    ThetaC = SgnA * ThetaC_in;
    dThetaC = SgnA * dThetaC_in;
    tmp_pst = ThetaC + pIp->csJPCPara_Param_PP[mode][axis].ThetaV;

    /* ������Ϊֱ�� */
    Switch1 = ThetaC - pIp->csJPCPara_Param_PP[mode][axis].ThetaD + pIp->csJPCPara_Param_PP[mode][axis].Kj1 * dThetaC;
    Switch2 = ThetaC + pIp->csJPCPara_Param_PP[mode][axis].ThetaD + pIp->csJPCPara_Param_PP[mode][axis].Kj1 * dThetaC;
    Switch3 = ThetaC - pIp->csJPCPara_Param_PP[mode][axis].ThetaB + pIp->csJPCPara_Param_PP[mode][axis].Kj2 * dThetaC;

    /* ��ʼΪ0�� */
    pIp->csJPCData_mPhase_Region[axis] = 0;

    /* �����ж� */
    if(Switch1 >= 0.0)
    {
        /* ������1���ұߣ�R11��R12��R13 �� */
        if(dThetaC >= pIp->csJPCPara_Param_PP[mode][axis].dThetaS)
        {
            /* R11�� */
            pIp->csJPCData_mPhase_Region[axis] = 0x11;
            pIp->csJPCData_mPhase_FJB[axis] = 0xA;  /* ���� */
            pIp->csJPCData_mPhase_T[axis] = pIp->csJPCPara_Param_PP[mode][axis].Tmax;
            pIp->csJPCData_mPhase_ThetaC_pst[axis]= tmp_pst;
        }
        else
        {
            /* R12 R13�� */
            if(Switch3 < 0.0)
            {
                if((dThetaC < pIp->csJPCPara_Param_PP[mode][axis].dThetaV) && (dThetaC >= 0.0))
                {
                    /* R13�� */
                    pIp->csJPCData_mPhase_Region[axis] = 0x13;

                    if(ThetaC < pIp->csJPCData_mPhase_ThetaC_pst[axis])
                    {
                        pIp->csJPCData_mPhase_FJB[axis] = 0x0;/* ���� */
                        pIp->csJPCData_mPhase_T[axis] = 0.0;
                        if(tmp_pst < pIp->csJPCData_mPhase_ThetaC_pst[axis])
                        {
                            /* ����(Thetac-Thetac_pst+ ThetaV)<0 */
                            pIp->csJPCData_mPhase_ThetaC_pst[axis] = tmp_pst;
                        }
                    }
                    else
                    {
                        pIp->csJPCData_mPhase_FJB[axis] = 0x5;  /* С�� */
                        pIp->csJPCData_mPhase_ThetaC_pst[axis] = tmp_pst;

                        TN1 = dThetaC / as_PP;
                        TN2 = pIp->csJPCPara_Param_PP[mode][axis].KJ * (ThetaC - pIp->csJPCPara_Param_PP[mode][axis].Dtheta) / as_PP;
                        tmp_TN = 0.5 * pIp->csJPCPara_Param_PP[mode][axis].Tmax;

                        if(TN2 >= tmp_TN)
                        {
                            TN2 = tmp_TN;
                        }

                        pIp->csJPCData_mPhase_T[axis] = TN1 + TN2;

                        if(pIp->csJPCData_mPhase_T[axis] < pIp->csJPCPara_Param_PP[mode][axis].Tmin)
                        {
                            pIp->csJPCData_mPhase_T[axis] = pIp->csJPCPara_Param_PP[mode][axis].Tmin;
                        }
                    }
                }
                /* else */
                if(dThetaC >= pIp->csJPCPara_Param_PP[mode][axis].dThetaV)
                {
                    /* R12�� */
                    pIp->csJPCData_mPhase_Region[axis] = 0x12;
                    pIp->csJPCData_mPhase_FJB[axis] = 0x5;  /* С�� */
                    pIp->csJPCData_mPhase_T[axis] = pIp->csJPCPara_Param_PP[mode][axis].Tmax;
                    pIp->csJPCData_mPhase_ThetaC_pst[axis] = tmp_pst;
                }
            }
        }
    }

    if((Switch2 < 0.0) && (dThetaC < 0.0))  /* R21�� */
    {
        pIp->csJPCData_mPhase_Region[axis]=0x21;
        pIp->csJPCData_mPhase_FJB[axis] = 0xA; /* ���� */
        pIp->csJPCData_mPhase_T[axis] = -pIp->csJPCPara_Param_PP[mode][axis].Tmax;
        pIp->csJPCData_mPhase_ThetaC_pst[axis] = tmp_pst;
    }
    if (Switch3 >= 0.0)
    {
        /* R15 R16 R17�� */
        if(dThetaC < -pIp->csJPCPara_Param_PP[mode][axis].dThetaLL)
        {
            /* R17�� */
            pIp->csJPCData_mPhase_Region[axis]=0x17;
            pIp->csJPCData_mPhase_FJB[axis] = 0xA; /* ���� */
            pIp->csJPCData_mPhase_T[axis] =  -pIp->csJPCPara_Param_PP[mode][axis].Tmax;
            pIp->csJPCData_mPhase_ThetaC_pst[axis] = tmp_pst;
        }
        else
        {
            /* R15 R16�� */
            if((dThetaC >= 0.0) && (dThetaC < pIp->csJPCPara_Param_PP[mode][axis].dThetaS))
            {
                /* R15�� */
                pIp->csJPCData_mPhase_Region[axis]=0x15;
                pIp->csJPCData_mPhase_FJB[axis] = 0xA; /* ���� */
                pIp->csJPCData_mPhase_T[axis]= (dThetaC + pIp->csJPCPara_Param_PP[mode][axis].dThetaL)/ aL_PP + pIp->csJPCPara_Param_PP[mode][axis].Tmin;
                pIp->csJPCData_mPhase_ThetaC_pst[axis] = tmp_pst;
            }
            if((dThetaC < 0.0) && (dThetaC >= -pIp->csJPCPara_Param_PP[mode][axis].dThetaL))
            {
                /* R16�� */
                pIp->csJPCData_mPhase_Region[axis]=0x16;
                pIp->csJPCData_mPhase_FJB[axis] = 0xA; /* ���� */
                pIp->csJPCData_mPhase_T[axis]=(pIp->csJPCPara_Param_PP[mode][axis].dThetaL + dThetaC)/ aL_PP + pIp->csJPCPara_Param_PP[mode][axis].Tmin;
                pIp->csJPCData_mPhase_ThetaC_pst[axis] = tmp_pst;
            }

        }
    }
    else
    {
        /* R14�� */
        if ((dThetaC < 0.0) && (dThetaC >= -pIp->csJPCPara_Param_PP[mode][axis].dThetaL) && (ThetaC >= pIp->csJPCPara_Param_PP[mode][axis].ThetaD))
        {
            pIp->csJPCData_mPhase_Region[axis]=0x14;
            if (ThetaC >= pIp->csJPCData_mPhase_ThetaC_pst[axis])
            {
                pIp->csJPCData_mPhase_FJB[axis] = 0x5;  /* С�� */
                pIp->csJPCData_mPhase_T[axis] = pIp->csJPCPara_Param_PP[mode][axis].Tmin;
                pIp->csJPCData_mPhase_ThetaC_pst[axis] = tmp_pst;
            }
            else
            {
                pIp->csJPCData_mPhase_FJB[axis] = 0x0;  /* ���� */
                pIp->csJPCData_mPhase_T[axis] = 0.0;
                if(tmp_pst < pIp->csJPCData_mPhase_ThetaC_pst[axis])
                {
                    /* ����(Thetac-Thetac_pst+ ThetaV)<0 */
                    pIp->csJPCData_mPhase_ThetaC_pst[axis] = tmp_pst;
                }
            }
        }
    }

    if(pIp->csJPCData_mPhase_Region[axis] == 0x0)
    {
        /* R0�� */
        pIp->csJPCData_mPhase_FJB[axis] = 0x0;
        pIp->csJPCData_mPhase_T[axis] = 0.0;
        pIp->csJPCData_mPhase_ThetaC_pst[axis] = ThetaC - pIp->csJPCPara_Param_PP[mode][axis].ThetaV;
    }

    /* ���������޷� */
    pIp->csJPCData_mPhase_T[axis] = LimitDouble(pIp->csJPCData_mPhase_T[axis], pIp->csJPCPara_Param_PP[mode][axis].Tmax);

    if (SgnA > 0)
    {
        pIp->csJPCData_mPhase_T[axis] = -pIp->csJPCData_mPhase_T[axis];
    }

    return;
}


void CS_AttCtrl_JetCrossSub(unint32 i, unint32 j, float64* csJPCData_mPhase_T, unint32* csJPCData_F_Jet, unint32* csJPCData_FJ)
{
    if ((csJPCData_mPhase_T[i] * csJPCData_mPhase_T[j]) > 1.0e-5)
    {
        if ((csJPCData_F_Jet[i] < csJPCData_F_Jet[j]) ||
            ((csJPCData_FJ[i + j - 1] == 0) && (csJPCData_F_Jet[i] == csJPCData_F_Jet[j])))
        {
            csJPCData_F_Jet[i] = 0;
            csJPCData_mPhase_T[i] = 0;
            csJPCData_FJ[i + j - 1] = 0x1; /* ���ο�j�� */
        }
        if (csJPCData_mPhase_T[i] > 1.0e-5)
        {
            csJPCData_F_Jet[j] = 0;
            csJPCData_mPhase_T[j] = 0;
            csJPCData_FJ[i + j - 1] = 0x0; /* ���ο�i�� */
        }

    }

    return;
}

void CS_AttCtrl_JetCrossCtrl(void *p)
{
    CS_AttCtrl_Propel *pIp = (CS_AttCtrl_Propel*)p;

    /* XY���˿���Ͻ������ */
    if (pIp->csJPCPara_FP_FJXYZ == 0x1)
    {
        CS_AttCtrl_JetCrossSub(0,1,pIp->csJPCData_mPhase_T,pIp->csJPCData_F_Jet,pIp->csJPCData_FJ);
    }

    /* XZ���˿���Ͻ������ */
    else if (pIp->csJPCPara_FP_FJXYZ == 0x2)
    {
        CS_AttCtrl_JetCrossSub(0,2,pIp->csJPCData_mPhase_T,pIp->csJPCData_F_Jet,pIp->csJPCData_FJ);
    }
    else
    {
        /* YZ���˿���Ͻ������ */
        if (pIp->csJPCPara_FP_FJXYZ == 0x3)
        {
            CS_AttCtrl_JetCrossSub(1,2,pIp->csJPCData_mPhase_T,pIp->csJPCData_F_Jet,pIp->csJPCData_FJ);
        }
    }


    //return;
}



void CS_FindMinMaxPos(unint32 *MinPos, unint32 *MaxPos, const float64 *a, const unint32 length)
{
    unint32 i;
    float64 min = 0.0;
    float64 max = 0.0;

    for (i=0; i<length; i++)
    {
        if (a[i] != 0.0)
        { /* �ҵ�һ����0ֵ��Ϊ���ֵ����Сֵ�ĳ�ֵ������������� */
            min = a[i];
            max = a[i];
            *MinPos = i;
            *MaxPos = i;
            break;
        }
    }

    for (; i<length; i++)   /* i��������ѭ����ֵ */
    {
        if (a[i] != 0.0)
        {
            if (a[i] < min)
            {
                min     = a[i];
                *MinPos = i;
            }
            if (a[i] >= max)
            {
                max     = a[i];
                *MaxPos = i;
            }
        }
    }
    return;
}

void CS_AttCtrl_Jet12Dis(void *p)
{
    CS_AttCtrl_Propel *pIp = (CS_AttCtrl_Propel*)p;
    float64 t_Thr_tmp[12][6];
    float64 sum_T, dt_Thr;
    float64 asTmp;
    unint32 k_max = 0;
    unint32 k_min = 0;
    unint32 k_mod;
    unint32 i, j, axis;
    unint32 sum_N, sum_N2;

    sum_N2 = 0;

    Memsetx((unint08 *)&t_Thr_tmp[0][0], 0x0, sizeof(t_Thr_tmp));

    /* (1) ���������� */
    /* a.1 */
    for (i=0; i<12; i++)
    {/* �����˿���� */

        pIp->csJPCData_t_AC[i] = 0.0;
        for (j=0; j<3; j++)
        {
            if (pIp->csJPCData_F_st[j] == 1)
            {
                t_Thr_tmp[i][2*j] = pIp->csJPCData_mPhase_T[j] * (float64)(pIp->csJPCPara_F_Assign[pIp->csJPCPara_FU&0x3][i][2*j]);
            }
            else
            {
                t_Thr_tmp[i][2*j+1] = pIp->csJPCData_mPhase_T[j] * (float64)(pIp->csJPCPara_F_Assign[pIp->csJPCPara_FU&0x3][i][2*j+1]);
            }
        }
    }

    /* a.2 ��ÿ����ܣ����ν����ж� */
    for (i=0; i<12; i++)
    {
        sum_T  = 0.0;           /* ���� */
        sum_N  = 0;

        for (j=0; j<6; j++)
        {
            sum_N = sum_N + pIp->csJPCPara_F_Assign[pIp->csJPCPara_FU&0x3][i][j];
            sum_T = sum_T + t_Thr_tmp[i][j];
        }
        dt_Thr = sum_T - pIp->m_DeltaT;

        if ((sum_N == 2) && (dt_Thr > 0.0))
        {
            CS_FindMinMaxPos( &k_min, &k_max,t_Thr_tmp[i], 6);

            if (k_min == pIp->csJPCData_F_AssignUse[i])
            {
                k_mod = k_max;
            }
            else
            {
                k_mod = k_min;
            }

            pIp->csJPCData_F_AssignUse[i] = k_mod;

            for (j=0; j<12; j++)
            {
                t_Thr_tmp[j][k_mod] = Maxx((t_Thr_tmp[j][k_mod] - dt_Thr), 0.0);
            }

            for (j=0; j<3; j++)
            {
                if ((k_mod == (2 * j)) || (k_mod == ( (2 * j) + 1)))
                {
                    pIp->csJPCData_mPhase_T[j] = Maxx((pIp->csJPCData_mPhase_T[j] - dt_Thr), 0.0);
                    break;
                }
            }
        }

    }

    for (i=0; i<12; i++)
    {
        /* �������ܵ�������� */
        for (j=0; j<6; j++)
        {
            pIp->csJPCData_t_AC[i] = pIp->csJPCData_t_AC[i] + t_Thr_tmp[i][j];
        }

        pIp->csJPCData_t_AC[i] = LimitDouble(pIp->csJPCData_t_AC[i], pIp->m_DeltaT);
    }

    /* b. ���ٶȼ��㼰����ʱ���ۼ� */
    for (axis=0; axis<3; axis++)
    {
        if (pIp->csJPCData_F_st[axis] == 1)
        {
            sum_N2 = 0;

            /* ��as����������ȡ��a_p */
            asTmp = pIp->csJPCPara_as[pIp->csModeData_F_PanelUnfold][pIp->csJPCPara_FU&0x3][2*axis + 0] * DEG2RAD;

            pIp->csJPCData_a[axis] = pIp->csJPCData_mPhase_T[axis] / pIp->m_DeltaT * asTmp * pIp->csJPCPara_Mdf_as_ACReal;

            for (i = 0; i < 12; i++)
            {
                /* 2*axis  F_Assign[��1�� ��1�� ����� ����� ������ ������] */
                sum_N2 = sum_N2 + pIp->csJPCPara_F_Assign[pIp->csJPCPara_FU&0x3][i][2 * axis];
            }
            pIp->csJPCData_SumTp[axis] = pIp->csJPCData_SumTp[axis] + (float64)(sum_N2) * pIp->csJPCData_mPhase_T[axis];
        }
        else
        {
            sum_N2 = 0;

            /* ��as����������ȡ��a_n */
            asTmp = pIp->csJPCPara_as[pIp->csModeData_F_PanelUnfold][pIp->csJPCPara_FU&0x3][2*axis + 1] * DEG2RAD;

            pIp->csJPCData_a[axis] = -pIp->csJPCData_mPhase_T[axis] / pIp->m_DeltaT * asTmp * pIp->csJPCPara_Mdf_as_ACReal;

            for (i=0; i<12; i++)
            {
                /* 2*axis  F_Assign[��1�� ��1�� ����� ����� ������ ������] */
                sum_N2 = sum_N2 + pIp->csJPCPara_F_Assign[pIp->csJPCPara_FU&0x3][i][2 * axis + 1];
            }
            pIp->csJPCData_SumTn[axis] = pIp->csJPCData_SumTn[axis] + (float64)(sum_N2) * pIp->csJPCData_mPhase_T[axis];
        }
    }

    /* 5.6.3.1.7    ���������������ۼƼ����ٶȼ��� */
    // CS_AttCtrl_SumCalc();
    float64 tmpSumTorq;

    /* �˿����������ٶȺ������ۼ��������� */
    for (i=0; i<3; i++)
    {
        tmpSumTorq = 0.0;

        for (j=0; j<12; j++)   //NUM_THRGR
        {
            tmpSumTorq += pIp->csJPCPara_Torq[j][i] * pIp->csJPCData_t_AC[j];
        }

        /* ����Ǽ��ٶ� */
        pIp->csJPCData_a2[i] = tmpSumTorq * pIp->csJPCPara_Mdf_as_ACReal / pIp->m_DeltaT / pIp->csCtrlerDataJs_Use[i][i];

        /* ����ʱ���ۼ� */
        if (pIp->csJPCData_a2[i] > 0.0)
        {
            pIp->csJPCData_SumTp2[i] += pIp->csJPCData_a2[i] / (pIp->csJPCData_apn[i][0] * pIp->csJPCPara_Mdf_as_ACReal) * pIp->m_DeltaT;
        }
        else
        {
            pIp->csJPCData_SumTn2[i] += Fabsx(pIp->csJPCData_a2[i]) / (pIp->csJPCData_apn[i][1] * pIp->csJPCPara_Mdf_as_ACReal) * pIp->m_DeltaT;
        }
    }

    return;
}