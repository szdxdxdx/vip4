#include "CS_OrbitComputation.h"

void SunEphemerisCalculate(void *p);
void OrbitCalculate(void *p);

void CS_OrbitComputationFun(void *p)
{
    CS_OrbitComputation *pIp = (CS_OrbitComputation*)p;
    float64 tmpF;
        unint32 i;

        /* (1) �������ѡȡ */
        if ((pIp->csOrbOtherPara_FP_OrbUpdate[pIp->m_WorkMode] == 1) &&
            (pIp->csOrbDataOther_F_DTOrbitEUpdate == 1))
        { /* �������¹������ �� ��̬������ģʽʹ��GPS���� */
            if ( (pIp->pGpsPara_FS_UseType == 1) || (pIp->pGpsPara_FS_UseType == 2) )       /* ����GPS����У�飨������ͨ���壩 */
            {
                // pIp->pOrbPara.t0 = pIp->pOrbG.t0;
                // pIp->pOrbPara.deltaa0 = pIp->pOrbG.deltaa0;
                // pIp->pOrbPara.adelta = pIp->pOrbG.adelta;
                // pIp->pOrbPara.i0 = pIp->pOrbG.i0;
                // pIp->pOrbPara.omg0 = pIp->pOrbG.omg0;
                // pIp->pOrbPara.omg1 = pIp->pOrbG.omg1;
                // pIp->pOrbPara.kesid = pIp->pOrbG.kesid;
                // pIp->pOrbPara.etad = pIp->pOrbG.etad;
                // pIp->pOrbPara.w1 = pIp->pOrbG.w1;
                // pIp->pOrbPara.etam = pIp->pOrbG.etam;
                // pIp->pOrbPara.a = pIp->pOrbG.a;
                // pIp->pOrbPara.beta = pIp->pOrbG.beta;
                // pIp->pOrbPara.lmd0 = pIp->pOrbG.lmd0;
                // pIp->pOrbPara.lmd1 = pIp->pOrbG.lmd1;
                // pIp->pOrbPara.lmd2 = pIp->pOrbG.lmd2;
                // pIp->pOrbPara.lmdg = pIp->pOrbG.lmdg;
                Memcpyx((unint08 *)&pIp->pOrbPara.t0, (unint08 *)&pIp->pOrbG.t0, sizeof(SOrbitParameterX));
            }
            else
            {
                // pIp->pOrbPara.t0 = pIp->pOrbI.t0;
                // pIp->pOrbPara.deltaa0 = pIp->pOrbI.deltaa0;
                // pIp->pOrbPara.adelta = pIp->pOrbI.adelta;
                // pIp->pOrbPara.i0 = pIp->pOrbI.i0;
                // pIp->pOrbPara.omg0 = pIp->pOrbI.omg0;
                // pIp->pOrbPara.omg1 = pIp->pOrbI.omg1;
                // pIp->pOrbPara.kesid = pIp->pOrbI.kesid;
                // pIp->pOrbPara.etad = pIp->pOrbI.etad;
                // pIp->pOrbPara.w1 = pIp->pOrbI.w1;
                // pIp->pOrbPara.etam = pIp->pOrbI.etam;
                // pIp->pOrbPara.a = pIp->pOrbI.a;
                // pIp->pOrbPara.beta = pIp->pOrbI.beta;
                // pIp->pOrbPara.lmd0 = pIp->pOrbI.lmd0;
                // pIp->pOrbPara.lmd1 = pIp->pOrbI.lmd1;
                // pIp->pOrbPara.lmd2 = pIp->pOrbI.lmd2;
                // pIp->pOrbPara.lmdg = pIp->pOrbI.lmdg;
                Memcpyx((unint08 *)&pIp->pOrbPara, (unint08 *)&pIp->pOrbI, sizeof(SOrbitParameterX));
            }

            if (pIp->csOrbOtherPara_FP_UseOtherOrb == 1)
            {
                /* Orb������������������������������������չ�� */
                f_Fun_Null();
            }
        }

        pIp->pObtOut_FV = 1;    /* ���������Ч */

        /* (2) ���á���Բ�е͹����ǹ�����������㷨���������ǹ�� */
        OrbitCalculate(pIp);
        SunEphemerisCalculate(pIp);

        /* (3) ����qoi */
        C2Q(pIp->pOrbData.qoi, pIp->pOrbData.coi[0]);

        /* (4) �����Ч���ж� */
        if (Fabsx(pIp->m_starTime_Next - pIp->pOrbPara.t0) >= pIp->csOrbInjChkPara_Lmt_dT)
        {
            pIp->pObtOut_FV = 0;    /* ���������Ч */
        }

        pIp->pObtOut_FV_NoInsert = 0;    /* �������ע�� */
        if (Fabsx(pIp->m_starTime_Next - pIp->pOrbPara.t0) >= (pIp->csOrbInjChkPara_Lmt_dT * 0.7))
        {
            pIp->pObtOut_FV_NoInsert = 1;    /* �������δע�� */
        }

        if (pIp->pOrbData.F_OrbAbnorm == 0)     /* �淶���㷨�����쳣w0 */
        {
            pIp->pObtOut_FV = 0;    /* ���������Ч */
        }

        if ((pIp->m_WorkMode != 0x09u) && (pIp->m_WorkMode != 0x08u) && (pIp->pObtOut_FV == 0))     /* ��������쳣 */
        {
            pIp->csOrbitErrJData_Cnt_NoOrb ++;
        }
        else
        {
            pIp->csOrbitErrJData_Cnt_NoOrb = 0;
        }

        if (pIp->csOrbitErrJData_Cnt_NoOrb >= pIp->csOrbitErrJPara_Num_NoOrb)
        {
            if (pIp->csOrbitErrJPara_FS_NoOrbPro == 0x0)
            {
                for (i=0; i<3; i++)
                {
                    pIp->pObtOut_F_SunlightZone[i] = 1;         /* ������ */
                }
                pIp->pOrbData.so[2] = -0.5;         /* ����Soֵ��ģΪ1 */
                pIp->pOrbData.so[1] =  0.5;
                pIp->pOrbData.so[0] =  0.707106781186548;
                pIp->pOrbData.w0     = pIp->csOrbInjChkPara_calc_w0_norm;
                pIp->pOrbData.cosrou = pIp->csOrbInjChkPara_calc_cosp_norm;
            }
            else
            {
                pIp->csOrbitErrJData_F_TurnAAM = 0x1;
            }
        }

        /* (5) ���� ���ǹ�������Ĺ��ϵ����ڹ���J2000.0�Ľ��ٶ� */
        if (pIp->csOrbOtherPara_FP_WoPrecession == 0)        /* �����ǹ������ */
        {
            pIp->pOrbData.w0i[0] = 0.0;
            pIp->pOrbData.w0i[1] = -pIp->pOrbData.w0;
            pIp->pOrbData.w0i[2] = 0.0;
        }
        else
        {
            pIp->pOrbData.w0i[0] = 0.0;
            pIp->pOrbData.w0i[1] = -pIp->pOrbData.w0;
            pIp->pOrbData.w0i[2] = -2.0 * pIp->pOrbPara.omg1 * Sinx(pIp->pOrbData.u) * Sinx(pIp->pOrbData.i);
        }

        /* (6)OrbOut.Cz_��G=Rz(Orb.��G + Earth.��*(t_next - Orb.t0)); */
        tmpF = pIp->pOrbPara.lmdg + pIp->pOCP_We * (pIp->m_starTime_Next - pIp->pOrbPara.t0);
        Rz(&pIp->pOrbData.Cz_lmdG[0][0], tmpF);

        pIp->pOrbData.lmdG = pIp->pOrbPara.lmdg + pIp->pOCP_We * (pIp->m_starTime_Next - pIp->pOrbPara.t0);


        return;
}


void SunEphemerisCalculate(void *p)
{
    CS_OrbitComputation *pIp = (CS_OrbitComputation*)p;
    float64 deltat;

    float64 msun;
    float64 comgsun;
    float64 somgsun;
    float64 susun;
    float64 cusun;
    float64 sisun;
    float64 cisun;

    deltat = pIp->m_starTime_Next - pIp->pOrbPara.t0;

    /* g. ̫���������λ���� */
    msun = pIp->pOCP_dMSun * deltat + pIp->pOrbPara.msun0;
    msun = ModPNHP(msun, PI);
    pIp->pOrbData.us = msun + 2.0 * pIp->pOCP_eSun * Sinx(msun) + pIp->pOrbPara.wsun + 1.25 * pIp->pOCP_eSun * pIp->pOCP_eSun * Sinx(2.0 * msun);
    pIp->pOrbData.us = ModPNHP(pIp->pOrbData.us, PI);

    somgsun = Sinx(pIp->pOrbPara.omgsun);
    comgsun = Cosx(pIp->pOrbPara.omgsun);
    susun = Sinx(pIp->pOrbData.us);
    cusun = Cosx(pIp->pOrbData.us);
    sisun = Sinx(pIp->pOCP_iSun);
    cisun = Cosx(pIp->pOCP_iSun);
    /* SI���� */
    pIp->pOrbData.si[0] = comgsun * cusun - somgsun * cisun * susun;
    pIp->pOrbData.si[1] = somgsun * cusun + comgsun * cisun * susun;
    pIp->pOrbData.si[2] = sisun * susun;

    /* SO���� */
    MatrixMulti(pIp->pOrbData.so, pIp->pOrbData.coi[0], pIp->pOrbData.si,  3, 3, 1);

    return;
}

void OrbitCalculate(void *point)
{
    CS_OrbitComputation *pIp = (CS_OrbitComputation*)point;
    unint32  counter;
    float64  deltat;
    float64  pp;
    float64  a2p;
    float64  si0;
    float64  ci0;
    float64  ssi;
    float64  s2n;
    float64  c2n;
    float64  as;
    float64  is;
    float64  omgs;
    float64  kesis;
    float64  etas;
    float64  lmds;
    float64  up;
    /* float64 prevup; */
    float64  ar;
    float64  te;
    float64  tef;
    float64  si;
    float64  ci;
    float64  su;
    float64  cu;
    float64  somg;
    float64  comg;
    float64  p;
    float64  dr;
    float64  h;
    float64  hh[3];
    float64  rdr;
    float64  rr;
    float64  tus;
    float64  tmpas1;
    float64  tmpas2;

    float64  us;
    float64  tmpas3;
    float64  tmpas4;
    float64  sUS;
    float64  cUS;

    counter = 0;
    deltat = pIp->m_starTime_Next - pIp->pOrbPara.t0;

    /* a. ƽ�������� */
    pIp->pOrbData.ap = pIp->pOCP_Re + pIp->pOrbPara.deltaa0 + pIp->pOrbPara.adelta * deltat; /* ~a */
    pIp->pOrbData.omgp = pIp->pOrbPara.omg0 + pIp->pOrbPara.omg1 * deltat; /* ~omg */
    pIp->pOrbData.omgp = ModPNHP(pIp->pOrbData.omgp, PI);
    pIp->pOrbData.kesip = pIp->pOrbPara.a * Cosx(pIp->pOrbPara.w1 * deltat - pIp->pOrbPara.beta) +  pIp->pOrbPara.kesid * deltat; /* ~ksi */
    pIp->pOrbData.etap = -pIp->pOrbPara.a * Sinx(pIp->pOrbPara.w1 * deltat - pIp->pOrbPara.beta) +  pIp->pOrbPara.etad * deltat + pIp->pOrbPara.etam; /* ~eta */
    pIp->pOrbData.lmdp = pIp->pOrbPara.lmd0 + pIp->pOrbPara.lmd1 * deltat + pIp->pOrbPara.lmd2 * deltat * deltat;/* ~lmd */
    pIp->pOrbData.lmdp = ModPNHP(pIp->pOrbData.lmdp, PI);
    pp = pIp->pOrbData.ap * (1.0 - pIp->pOrbData.kesip * pIp->pOrbData.kesip - pIp->pOrbData.etap * pIp->pOrbData.etap); /* ~p */
    pIp->pOrbData.ip = pIp->pOrbPara.i0;

    /* b. ����������� */
    /* ��Բ���,����Բ��� */
    a2p = pIp->pOCP_A2 / (pp * pp);
    si0 = Sinx(pIp->pOrbPara.i0);
    ci0 = Cosx(pIp->pOrbPara.i0);
    ssi = si0 * si0;

    up = pIp->pOrbData.lmdp;
    do
    {
        counter++;  /* �������� */

        /* prevup = up; */
        up = pIp->pOrbData.lmdp + pIp->pOrbData.kesip * Sinx(up) + pIp->pOrbData.etap * Cosx(up);
    } while(counter < 6);

    /* ��Բ�������������� */
    ar = 1.0 / (1.0 - pIp->pOrbData.kesip * Cosx(up) + pIp->pOrbData.etap * Sinx(up));

    //tus = ar * (up-lmdp) * (1.0 + 0.5 * etap * Sinx(up) - 0.5 * kesip * Cosx(up));
    tus = ar * (up-pIp->pOrbData.lmdp) * (1.0 + 1.0 / (1.0 + Sqrtx(1.0 - (pIp->pOrbData.kesip * pIp->pOrbData.kesip + pIp->pOrbData.etap * pIp->pOrbData.etap)))
                                *(pIp->pOrbData.etap * Sinx(up) - pIp->pOrbData.kesip * Cosx(up)) );
    tus = LimitDouble(tus,1.0);
    us = up + Asinx(tus);

    s2n = Sinx(2.0 * us);
    c2n = Cosx(2.0 * us);

    /* a~
    as    = ocp->A2 * (2.0/3.0 * (1.0 - 1.5*ssi) * (ar * ar * ar - 1.0 - 1.5*(kesip * kesip + etap * etap))
                        + ssi * ar * ar * ar * c2n) / ap;
    To avoid SOC2008 CPU abnomal trap8 reset, break fmuld-fmuld-fdivd-fmuld-std-call order,Modify above code sequence fxt  */

    tmpas1 = pIp->pOCP_A2 / pIp->pOrbData.ap;
    tmpas2 = 2.0/3.0 * (1.0 - 1.5*ssi);
    tmpas3 = ar * ar * ar - 1.0 - 1.5*(pIp->pOrbData.kesip * pIp->pOrbData.kesip + pIp->pOrbData.etap * pIp->pOrbData.etap);
    tmpas4 = ssi * ar * ar * ar * c2n;

    as = tmpas1 * (tmpas2 * tmpas3 + tmpas4);

    sUS = Sinx(us);
    cUS = Cosx(us);

    /* i~ */
    is    = a2p * si0 * ci0 * (pIp->pOrbData.kesip * cUS + pIp->pOrbData.etap * sUS + c2n
                                + 1.0 / 3.0 * (pIp->pOrbData.kesip * Cosx(3.0 * us) - pIp->pOrbData.etap * Sinx(3.0 * us))) / 2.0;
    /* omg~ */
    omgs  = a2p * ci0 * (-(us - pIp->pOrbData.lmdp) - (0.5 * pIp->pOrbData.kesip * sUS + 1.5 * pIp->pOrbData.etap * cUS)
                            + 0.5 * s2n + 1.0/6.0 * (pIp->pOrbData.kesip * Sinx(3.0*us) + pIp->pOrbData.etap * Cosx(3.0*us))  )  ;
    /* kesi~ */
    kesis = a2p * (cUS + 0.5 * pIp->pOrbData.kesip * c2n - pIp->pOrbData.etap * s2n + pIp->pOrbData.kesip
                    + ssi * (-1.25 * cUS + 0.5 * pIp->pOrbData.kesip * c2n + 2.0 * pIp->pOrbData.etap * s2n
                            + 7.0 / 12.0 * Cosx(3.0*us) + 0.375 * (pIp->pOrbData.kesip * Cosx(4.0*us) - pIp->pOrbData.etap * Sinx(4.0*us)) - 1.25*pIp->pOrbData.kesip));
    /* eta~ */
    etas  = a2p * (-sUS - 0.5 * pIp->pOrbData.etap * c2n + pIp->pOrbData.etap
                    + ssi *(1.75 * sUS - 0.5 * pIp->pOrbData.kesip * s2n + 2.0 * pIp->pOrbData.etap * c2n
                            - 7.0 / 12.0 * Sinx(3.0*us) - 0.375 * (pIp->pOrbData.kesip * Sinx(4.0*us) + pIp->pOrbData.etap * Cosx(4.0*us)) - 1.25*pIp->pOrbData.etap));
    /* lmd~ */
    lmds  = -ci0 * omgs + a2p * ((1.0 - 1.5*ssi)*(us - pIp->pOrbData.lmdp) + 1.5 * (pIp->pOrbData.kesip * sUS + pIp->pOrbData.etap * cUS)
                                    + ssi * (-1.625 * pIp->pOrbData.kesip * sUS - 2.875 * pIp->pOrbData.etap * cUS + 0.75*s2n
                                    + 13.0/24.0 * (pIp->pOrbData.kesip * Sinx(3.0*us) + pIp->pOrbData.etap * Cosx(3.0 * us) )));

    /* c. ˲ʱ����������� */
    pIp->pOrbData.a = pIp->pOrbData.ap+ as;  /* ����a���� */
    pIp->pOrbData.i = pIp->pOrbPara.i0 + is; /* ����i���� */
    pIp->pOrbData.omg = pIp->pOrbData.omgp + omgs; /* ����omg���� */
    pIp->pOrbData.omg = ModPNHP(pIp->pOrbData.omg, PI);

    pIp->pOrbData.kesi = pIp->pOrbData.kesip + kesis; /* ����ksi���� */
    pIp->pOrbData.eta = pIp->pOrbData.etap + etas;

    pIp->pOrbData.lmd = pIp->pOrbData.lmdp + lmds;  /* ����lmd���� */
    pIp->pOrbData.lmd = ModPNHP(pIp->pOrbData.lmd, PI);

    /* ����e���� */
    pIp->pOrbData.e = Sqrtx(pIp->pOrbData.kesi * pIp->pOrbData.kesi + pIp->pOrbData.eta * pIp->pOrbData.eta);

    up = pIp->pOrbData.lmd;
    counter = 0;

    do
    {
        counter++;  /* �������� */

        /* prevup = up; */
        up = pIp->pOrbData.lmd + pIp->pOrbData.kesi * Sinx(up) + pIp->pOrbData.eta * Cosx(up);
    } while(counter < 6);

    ar = 1.0 / (1.0 - pIp->pOrbData.kesi * Cosx(up) + pIp->pOrbData.eta * Sinx(up));

    te = Sqrtx(1.0 - pIp->pOrbData.e * pIp->pOrbData.e);
    /* ����u���� */
    tus = ar * (up - pIp->pOrbData.lmd) *
        (1.0 + (pIp->pOrbData.eta * Sinx(up) - pIp->pOrbData.kesi * Cosx(up)) / (1.0 + te));
    tus = LimitDouble(tus,1.0);
    pIp->pOrbData.u = up + Asinx(tus);
    pIp->pOrbData.u = ModPNHP(pIp->pOrbData.u, PI);

    /* ����r���� */
    pIp->pOrbData.r = pIp->pOrbData.a / ar;

    /* ����w���� */
    pIp->pOrbData.w = Atan2x(-pIp->pOrbData.eta, pIp->pOrbData.kesi);

    /* ����f���� */
    pIp->pOrbData.f  = pIp->pOrbData.u - pIp->pOrbData.w;
    pIp->pOrbData.f  = ModPNHP(pIp->pOrbData.f , PI);

    tef = Sqrtx(pIp->pOCP_Mu * pIp->pOrbData.a) * te;

    /* ����w0���� */
    pIp->pOrbData.w0 = tef / (pIp->pOrbData.r * pIp->pOrbData.r);

    /* w0����ж� */
    if (Fabsx(pIp->pOrbData.w0 - pIp->csOrbInjChkPara_calc_w0_norm) > pIp->csOrbInjChkPara_calc_Lmt_dw0)
    {
        pIp->pOrbData.w0 = pIp->csOrbInjChkPara_calc_w0_norm;
        pIp->pOrbData.r = pIp->csOrbInjChkPara_calc_r_norm;
        pIp->pOrbData.F_OrbAbnorm = 0;
    }
    else
    {
        pIp->pOrbData.F_OrbAbnorm = 1;
    }

    /* d. �������ϵ�����J2000.0��Ԫ��������ϵ��˲ʱƽ�����������ϵ���������� */
    si   = Sinx(pIp->pOrbData.i);
    ci   = Cosx(pIp->pOrbData.i);
    su   = Sinx(pIp->pOrbData.u);
    cu   = Cosx(pIp->pOrbData.u);
    somg = Sinx(pIp->pOrbData.omg);
    comg = Cosx(pIp->pOrbData.omg);

    /* coi���� */
    pIp->pOrbData.coi[0][0] = -su * comg - cu * ci * somg;
    pIp->pOrbData.coi[0][1] = -su * somg + cu * ci * comg;
    pIp->pOrbData.coi[0][2] =  cu * si;

    pIp->pOrbData.coi[1][0] = -si * somg;
    pIp->pOrbData.coi[1][1] =  si * comg;
    pIp->pOrbData.coi[1][2] = -ci;

    pIp->pOrbData.coi[2][0] = -cu * comg + su * ci * somg;
    pIp->pOrbData.coi[2][1] = -cu * somg - su * ci * comg;
    pIp->pOrbData.coi[2][2] = -su * si;

    /* e. ���ľ���L��γ�Ȧĺ͵�����Ž����Ҽ��� */
    pIp->pOrbData.l1 = Atan2x(su * ci, cu);
    pIp->pOrbData.l = pIp->pOrbData.l1 + pIp->pOrbData.omg - pIp->pOrbPara.lmdg - pIp->pOCP_We * deltat;
    pIp->pOrbData.l = ModPNHP(pIp->pOrbData.l, PI);
    pIp->pOrbData.delta = Asinx(su * si);
    pIp->pOrbData.cosrou = Sqrtx(Fabsx(pIp->pOrbData.r * pIp->pOrbData.r - (pIp->pOCP_Re + pIp->pOCP_Hco2) * (pIp->pOCP_Re + pIp->pOCP_Hco2)))/pIp->pOrbData.r;

    /* f.����ϵ��λ�ú��ٶȼ��� */
    pIp->pOrbData.pos[0] = pIp->pOrbData.r * (comg * cu - somg * ci * su);
    pIp->pOrbData.pos[1] = pIp->pOrbData.r * (somg * cu + comg * ci * su);
    pIp->pOrbData.pos[2] = pIp->pOrbData.r * si * su;

    p = pIp->pOrbData.a * (1.0 - pIp->pOrbData.e * pIp->pOrbData.e);
    dr = pIp->pOrbData.e * Sinx(pIp->pOrbData.f ) * Sqrtx(pIp->pOCP_Mu / p);
    h = Sqrtx(pIp->pOCP_Mu * p);
    hh[0] =  h * si * somg;
    hh[1] = -h * si * comg;
    hh[2] =  h * ci;

    rdr = pIp->pOrbData.r * dr;
    rr = pIp->pOrbData.r * pIp->pOrbData.r;
    /* ���µ��ٶȼ��� */
    pIp->pOrbData.rate[0] = (pIp->pOrbData.pos[2] * hh[1] - pIp->pOrbData.pos[1] * hh[2] + pIp->pOrbData.pos[0] * rdr) / rr;
    pIp->pOrbData.rate[1] = (pIp->pOrbData.pos[0] * hh[2] - pIp->pOrbData.pos[2] * hh[0] + pIp->pOrbData.pos[1] * rdr) / rr;
    pIp->pOrbData.rate[2] = (pIp->pOrbData.pos[1] * hh[0] - pIp->pOrbData.pos[0] * hh[1] + pIp->pOrbData.pos[2] * rdr) / rr;

    return;
}