#include "ModeConvert_EIM.h"

void ModeConvert_EIMFun(void *p)
{
    ModeConvert_EIM *pIp = (ModeConvert_EIM*)p;

    if ( pIp->ModeObject_Timer_Mode[pIp->m_WorkMode] > pIp->csModePara_dt_END_EIM )    /* ʱ�䵽 */
    {
        pIp->m_WorkMode = 0x02u;      /* ת������ģʽ */
    }

    return;
}